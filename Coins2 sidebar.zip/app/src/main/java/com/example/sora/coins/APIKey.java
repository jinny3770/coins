package com.example.sora.coins;

/**
 * Created by sora on 2016-03-16.
 */
public class APIKey {

    public static final String ApiKey = "6c5f4b2637e6da1752988c0e60b3ddc8";


}
