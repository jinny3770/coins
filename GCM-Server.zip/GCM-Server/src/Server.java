import java.io.IOException;
import com.google.android.gcm.server.Constants;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
 
public class Server 
{
 	public void sendMessage() throws IOException 
 	{	 
		Sender sender = new Sender("AIzaSyAfClZJckVp_ZFNWWdl_kVOJFX2qzoP18s");		 
		String regID = "APA91bGFf-bVXOr-cddNpF4zNuGl2E-Aw9C3bOAQE8NoBdpI-LdOrW44QDV-zvIIuihLFYPpRKdEjtgJQzFT2yMibhUB8Q7qeBnMEh64FaSwj939zp5rtHcvHlN82Zq2XElWWG_Z4__QBVmjAPRi4zu_TQ_4oKuejw";	 
		Message message = new Message.Builder().addData("message", "pupupupu").build();
		
		Result result = sender.send(message, regID, 5);
		
		if (result.getMessageId() != null)
		{
			System.out.println("Ǫ�� �׽�Ʈ");
		}
		
		else
		{
			String error = result.getErrorCodeName();
			System.out.println(error);
			
			if (Constants.ERROR_INTERNAL_SERVER_ERROR.equals(error))
			{
				System.out.println("���� ���� ����");

			}
		}
		
		/*List<String> list = new ArrayList<String>();
		list.add(regID);
		MulticastResult multiResult;
		
		try 
		{
			multiResult = sender.send(message, list, 5);
		
			if (multiResult != null) 
			{
				List<Result> resultList = multiResult.getResults();
		
				for (Result result : resultList) 
				{
					System.out.println(result.getMessageId());
				}
			}
		} 
		
		catch (IOException ioe) 
		{
			ioe.printStackTrace();
		} */
	}
		 
	public static void main(String[] args) throws Exception 
	{	 
		Server s = new Server();
		s.sendMessage();
	} 
}

/*import java.io.IOException;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
 
public class GcmServer 
{
	private static String API_KEY = "AIzaSyAfClZJckVp_ZFNWWdl_kVOJFX2qzoP18s"; // ������Ʈ api key
	private static String REG_ID = "APA91bH4YT1HFrWlW9_J4Re0YNn2wooHuWoszU8PYPFyKXoCy0DAJo0QwVORq-ov497Eipu-luek3Fvlbel9aSMffcn5HGMEfy4LjbDcJVTbSNYzdF97FmZNzsvYDIV3jhVnrquBmSbt20xPyDEVNExFu9hlGtzaLA";  // �ܸ��� registrationId
	
	public static void main (String args[]) throws InterruptedException, IOException 
	{
		sendPush();
	}
	
	public static void sendPush() throws IOException  
	{
		Sender sender = new Sender(API_KEY);
		Message msg = new Message.Builder().addData(API_KEY, "Push Message").build();
		
		Result result = sender.send(msg, REG_ID, 5);
		
		if(result.getMessageId() != null) 
		{
			System.out.println("Ǫ��Ǫ��");
		}
		
		else 
		{
			String error = result.getErrorCodeName();
			System.out.println(error);
		}
	}
}*/