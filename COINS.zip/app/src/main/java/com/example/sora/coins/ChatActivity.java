package com.example.sora.coins;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by sora on 2016-03-17.
 */
public class ChatActivity extends AppCompatActivity {


}
