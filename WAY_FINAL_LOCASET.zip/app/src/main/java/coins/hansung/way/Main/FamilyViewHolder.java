package coins.hansung.way.Main;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sora on 2016-04-14.
 */
public class FamilyViewHolder
{
    public ImageView icon;
    public TextView name;
    public TextView loca;
    public TextView gps;
    public TextView battery;
    public ImageView profileImage;
}
