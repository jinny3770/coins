package coins.hansung.way.Destination;

import android.widget.ImageView;

/**
 * Created by sora on 2016-05-31.
 */
public class SpinnerHolder {

    ImageView image;
}
