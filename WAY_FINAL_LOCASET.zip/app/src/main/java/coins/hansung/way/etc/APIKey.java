package coins.hansung.way.etc;

/**
 * Created by sora on 2016-03-16.
 */

public class APIKey
{
    public static final String ApiKey = "690b7bf3-50c2-361a-b27f-e04d4b84ee71";
}