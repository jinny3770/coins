package coins.hansung.way.NFC;

/**
 * Created by Administrator on 2016-05-13.
 */
public interface ParsingRecord
{
    public static final int TYPE_TEXT = 1;
    public int getType();
}
