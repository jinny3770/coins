package coins.hansung.way.Destination;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sora on 2016-05-06.
 */
public class DestinationHolder {

    public ImageView icon;
    public TextView name, arrive, departure;
}
