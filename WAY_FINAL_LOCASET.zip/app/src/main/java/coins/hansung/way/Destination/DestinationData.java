package coins.hansung.way.Destination;

import android.graphics.drawable.Drawable;

/**
 * Created by sora on 2016-05-06.
 */
public class DestinationData {

    public Drawable icon;
    public String type;
    public String name, arrive, departure, time;

}
