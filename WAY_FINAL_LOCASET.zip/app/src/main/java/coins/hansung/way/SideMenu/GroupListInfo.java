package coins.hansung.way.SideMenu;

/**
 * Created by Administrator on 2016-05-30.
 */
public class GroupListInfo
{
    public String name, number;

    public GroupListInfo(String name, String number)
    {
        this.name = name;
        this.number = number;
    }
}
