package com.example.sora.coins;

/**
 * Created by sora on 2016-03-23.
 */
public class PersonInfo {

    private String ID;
    private String name;


    public PersonInfo(String ID, String name){
        this.ID = ID;
        this.name = name;
    }

    public void setID (String ID) {
        this.ID = ID;
    }

    public void setName (String name) {
        this.name = name;
    }
}
